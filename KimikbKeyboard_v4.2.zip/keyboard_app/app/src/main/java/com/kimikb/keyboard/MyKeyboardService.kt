package com.kimikb.keyboard

import android.content.ClipboardManager
import android.content.SharedPreferences
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Vibrator
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

class MyKeyboardService : InputMethodService(), KeyboardView.Listener {

    enum class Page { AR, FR, EN, NUM, NUMPAD, SYM, EMOJI }

    private lateinit var prefs: SharedPreferences
    private lateinit var container: LinearLayout
    private lateinit var candidateBar: LinearLayout
    private lateinit var kv: KeyboardView

    private var page = Page.AR
    private var lastAlpha = Page.AR
    private var lastLatin = Page.FR
    private var shift = false
    private var capsLock = false

    private val arWords = ("في من على إلى عن هذا ذلك الذي التي ما لا لم لن قد كان يكون مع هو هي نحن أنا أنت أنتم هم هن " +
        "فيه منه عليه عليها عند بعد قبل بين كل بعض غير أي أو ثم كما لكن لأن لذلك حتى إذا كيف لماذا أين متى أيضا " +
        "جدا الآن هنا هناك اليوم غدا أمس أريد أحب أعمل أذهب تعال اكتب إقرأ اسم كتاب ماء خبز بيت ولد بنت صباح " +
        "مساء ليل نهار شمس قمر وقت سنة أسبوع جميل كبير صغير جديد طويل قصير جيد سيء حار بارد سريع بطيء").split(" ")

    private val frWords = ("le la les des une un et est dans pour avec qui que sur pas plus moi vous tu il elle nous " +
        "sont été faire pourquoi comment quand où aussi très bien merci beaucoup aujourd'hui demain hier maison " +
        "eau pain livre garçon fille soleil lune chat chien voiture travail école ami famille bonjour bonsoir " +
        "salut oui non voilà temps année semaine jour monde pays ville grand petit nouveau beau bon mauvais").split(" ")

    private val enWords = ("the be to of and a in that have it for not on with he as you do at this but his by from they we say her she or an will my one all would there their what so up out if about who get which go me when make can like time no just him know take people into year your good some could them see other than then now look only come its over think also back after use two how our work first well way even new want because any these give day most us").split(" ")

    // ---------------- lifecycle ----------------

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("kb_prefs", MODE_PRIVATE)
        clipStore = ClipboardStore(this)
        clipManager = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipManager.addPrimaryClipChangedListener(clipListener)
        SttBridge.ui = sttSink
    }

    override fun onDestroy() {
        stopSr()
        if (SttBridge.ui === sttSink) SttBridge.ui = null
        if (::clipManager.isInitialized) clipManager.removePrimaryClipChangedListener(clipListener)
        super.onDestroy()
    }

    override fun onCreateInputView(): View {
        prefs = getSharedPreferences("kb_prefs", MODE_PRIVATE)
        container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        candidateBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        kv = KeyboardView(this)
        kv.listener = this
        // spelling-game category bar: pick ONE or MORE categories (or ALL)
        catLabel = TextView(this).apply {
            textSize = 14f
            visibility = View.GONE
            val p = (resources.displayMetrics.density * 14).toInt()
            setPadding(p, 10, p, 10)
        }
        // 8 chips do not fit in one row -> two rows of 4
        val chipsRow1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val chipsRow2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val allKeys = catNames.keys.toList() + ALL_KEY
        allKeys.forEachIndexed { i, key ->
            val name = if (key == ALL_KEY) "✨ الكل" else catNames[key]!!
            val chip = TextView(this).apply {
                text = name
                textSize = 13f
                gravity = Gravity.CENTER
                val p = (resources.displayMetrics.density * 4).toInt()
                val v = (resources.displayMetrics.density * 10).toInt()
                setPadding(p, v, p, v)
                setOnClickListener { toggleCategory(key) }
            }
            catChips[key] = chip
            val row = if (i < 4) chipsRow1 else chipsRow2
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            val m = (resources.displayMetrics.density * 3).toInt()
            lp.setMargins(m, m, m, m)
            row.addView(chip, lp)
        }
        catBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            addView(chipsRow1)
            addView(chipsRow2)
            addView(catLabel)
        }
        container.addView(catBar, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        container.addView(candidateBar, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        container.addView(kv, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        clipPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        container.addView(clipPanel, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        scPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        container.addView(scPanel, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        buildBars()
        refresh()
        return container
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        if (::clipPanel.isInitialized && clipPanel.visibility == View.VISIBLE) hideClipPanel()
        if (scVisible()) hideScPanel()
        scSelected.clear()
        if (!restarting) {
            val def = if (prefs.getInt("default_lang", 0) == 0) Page.AR else Page.FR
            if (page == Page.AR || page == Page.FR) { page = def; lastAlpha = def }
        }
        refresh()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        stopSr()
        super.onFinishInputView(finishingInput)
    }

    override fun onCreateCandidatesView(): View? = null

    // ---------------- themes / helpers ----------------

    private fun theme(): Int = prefs.getInt("theme", 1)
    private fun soundOn(): Boolean = prefs.getBoolean("sound", true)

    private val vib by lazy { getSystemService(VIBRATOR_SERVICE) as? Vibrator }
    private val audio by lazy { getSystemService(AUDIO_SERVICE) as? AudioManager }

    private fun haptic() {
        if (!prefs.getBoolean("vibrate", true)) return
        @Suppress("DEPRECATION") vib?.vibrate(12)
    }

    private fun clickSound() {
        if (!soundOn()) return
        audio?.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD, 0.6f)
    }

    private fun specs(s: String) = s.trim().split(Regex("\\s+")).map { KeySpec(it, it) }

    // "ض:١ ص:٢" -> keys with small corner hints (numbers / alternate letters)
    private fun specsH(s: String) = s.trim().split(Regex("\\s+")).map {
        val p = it.split(":")
        KeySpec(p[0], p[0], 1f, if (p.size > 1) p[1] else "")
    }

    // ----- dynamic Enter/Send key (like iPhone) -----
    private fun enterAction(): Int {
        val ei = currentInputEditorInfo ?: return EditorInfo.IME_ACTION_NONE
        if (ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION != 0)
            return EditorInfo.IME_ACTION_NONE
        return ei.imeOptions and EditorInfo.IME_MASK_ACTION
    }

    private fun sendLabel(): String = when (enterAction()) {
        EditorInfo.IME_ACTION_SEARCH -> "بحث"
        EditorInfo.IME_ACTION_GO     -> "انتقال"
        EditorInfo.IME_ACTION_DONE   -> "تم"
        EditorInfo.IME_ACTION_NEXT   -> "التالي"
        else -> when (lastAlpha) { Page.FR -> "envoyer"; Page.EN -> "send"; else -> "إرسال" }
    }

    private fun none(w: Float) = KeySpec("", "@NONE", w)

    // globe (language) at the left, microphone (voice typing) at the right — below the keys
    private fun utilRow() = listOf(
        KeySpec("🌐", "@LANG", 1.3f, flat = true, h = 0.72f),
        none(8f),
        KeySpec("🎙", "@MIC", 1.3f, flat = true))

    private fun latinBottom(space: String) = listOf(
        KeySpec("123", "@NUM", 1.3f), KeySpec("😊", "@EMOJI", 1.3f),
        KeySpec(space, "@SPACE", 5.2f), KeySpec(sendLabel(), "@SEND", 2.7f))

    private fun rowsFor(p: Page): List<List<KeySpec>> = when (p) {
        // Arabic: layout copied from the reference picture (3 rows of letters, no shift)
        Page.AR -> listOf(
            specsH("ض:١ ص:٢ ث:٣ ق:٤ ف:٥ غ:٦ ع:٧ ه:٨ خ:٩ ح:٠ ج"),
            specsH("ش س ى ب ل:لا ا:أ ت ن م ك ة"),
            specsH("ء:أ ظ ط ذ د ز ر و:ؤ ي:ئ") + none(0.7f) + KeySpec("⌫", "@DEL", 1.3f),
            listOf(KeySpec("123", "@NUM", 1.3f), KeySpec("😊", "@EMOJI", 1.3f),
                KeySpec("مسافة", "@SPACE", 4.1f),
                KeySpec("◌ً", "tash", 1.3f, out = "ً"),
                KeySpec(sendLabel(), "@SEND", 2.9f)),
            utilRow()
        )
        // French AZERTY (reference picture)
        Page.FR -> listOf(
            specsH("a:1 z:2 e:3 r:4 t:5 y:6 u:7 i:8 o:9 p:0"),
            specs("q s d f g h j k l m"),
            listOf(KeySpec("⇧", "@SHIFT", 1.5f)) + specsH("w x c:ç v b n") +
                listOf(KeySpec("´", "´"), KeySpec("⌫", "@DEL", 1.5f)),
            latinBottom("Français (France)"),
            utilRow()
        )
        Page.EN -> listOf(
            specsH("q:1 w:2 e:3 r:4 t:5 y:6 u:7 i:8 o:9 p:0"),
            listOf(none(0.5f)) + specs("a s d f g h j k l") + none(0.5f),
            listOf(KeySpec("⇧", "@SHIFT", 1.5f)) + specs("z x c v b n m") +
                listOf(KeySpec("⌫", "@DEL", 1.5f)),
            latinBottom("English"),
            utilRow()
        )
        // Numbers: vertical 3-column pad with side columns, shown directly (reference picture)
        Page.NUM -> listOf(
            listOf(KeySpec("أبجد", "@ABC", 1.15f)) + specs("1 2 3") + KeySpec("⌫", "@DEL", 1.15f),
            listOf(KeySpec("#@$", "@SYM", 1.15f)) + specs("4 5 6") + KeySpec("⏎", "@ENTER", 1.15f),
            listOf(KeySpec("ABC", "@ABCL", 1.15f)) + specs("7 8 9") +
                KeySpec(sendLabel(), "@SEND", 1.15f, span = 2),
            listOf(KeySpec("😊", "@EMOJI", 1.15f), KeySpec(".,:", ".", 1f, out = "."),
                KeySpec("0", "0"), KeySpec("مسافة", "@SPACE", 1f), KeySpec("", "@COVER", 1.15f)),
            utilRow()
        )
        Page.NUMPAD -> listOf(
            listOf(KeySpec(".", ".", 0.55f)) + specs("1 2 3") +
                listOf(KeySpec("⌫", "@DEL", 1.1f)),
            listOf(KeySpec("+", "+", 0.55f)) + specs("4 5 6") +
                listOf(KeySpec("@", "@", 1.1f)),
            listOf(KeySpec("/", "/", 0.55f)) + specs("7 8 9") +
                listOf(KeySpec(sendLabel(), "@SEND", 1.1f)),
            listOf(KeySpec("-", "-", 0.55f), KeySpec("🌐", "@LANG", 1f),
                KeySpec("0", "0", 2.3f), KeySpec("٪؟!", "@PUNCT", 1.2f),
                KeySpec("أبجد", "@ABC", 1.3f))
        )
        Page.SYM -> listOf(
            specs("- / : ; ( ) € & @ \""),
            specs("~ ` | • √ π ÷ × § #"),
            specs("_ ^ [ ] { } ¶ £ ¥ %"),
            listOf(KeySpec("123", "@NUM", 1.5f)) + specs(". , ? ! ' ٪ ؟") +
                listOf(KeySpec("⌫", "@DEL", 1.5f)),
            listOf(KeySpec("أبجد", "@ABC", 1.4f), KeySpec("😊", "@EMOJI", 1.3f),
                KeySpec("مسافة", "@SPACE", 4.5f), KeySpec(sendLabel(), "@SEND", 2.4f)),
            utilRow()
        )
        Page.EMOJI -> listOf(
            specs("😀 😂 🤣 😊 😍 😘 😜 🤪"),
            specs("😎 😢 😡 👍 👎 🙏 👏 💪"),
            specs("❤️ 🔥 ✨ 🎉 🌹 🍀 ☀️ 🌙"),
            specs("🐱 🐶 ⚽ 🎮 🚗 ✈️ 🎵 📱") +
                listOf(KeySpec("⌫", "@DEL", 1.0f)),
            listOf(KeySpec("أبجد", "@ABC", 1.4f), KeySpec("🌐", "@LANG", 1.0f),
                KeySpec("مسافة", "@SPACE", 3.5f), KeySpec("⚙", "@SET", 1.1f),
                KeySpec(sendLabel(), "@SEND", 1.9f))
        )
    }

    private fun refresh() {
        val c = colors()
        catLabel.setTextColor(c.third)
        updateCatUI()
        kv.shiftActive = shift
        kv.capsActive = capsLock
        kv.showHints = prefs.getBoolean("hints", true)
        kv.applyTheme(theme())
        kv.rows = rowsFor(page)
        kv.micActive = micOn()
        container.setBackgroundColor(Themes.get(theme()).bg)
        if (clipPanel.visibility == View.VISIBLE) rebuildClipPanel()
        if (scVisible()) rebuildScPanel()
        lastSig = ""
        updateCandidates()
    }

    // ---------------- keyboard view listener ----------------

    private fun separate(): Boolean = prefs.getBoolean("separate", false)

    // ----- spelling game: pick one or more categories, type a letter, word is sent -----
    private lateinit var catBar: LinearLayout
    private lateinit var catLabel: TextView
    private val catChips = linkedMapOf<String, TextView>()
    private val selectedCats = mutableSetOf<String>()

    private val catNames = linkedMapOf(
        "boy" to "👦 ولد", "girl" to "👧 بنت", "thing" to "🪨 جماد", "animal" to "🦁 حيوان",
        "plant" to "🌱 نبات", "country" to "🌍 دولة", "capital" to "🏛️ عاصمة"
    )

    private val catData = mapOf(
        "boy" to mapOf('ا' to "أحمد",'ب' to "بلال",'ت' to "توفيق",'ث' to "ثابت",'ج' to "جمال",
            'ح' to "حسن",'خ' to "خالد",'د' to "داود",'ذ' to "ذو الفقار",'ر' to "ريان",
            'ز' to "زيد",'س' to "سعيد",'ش' to "شكيب",'ص' to "صهيب",'ض' to "ضياء",
            'ط' to "طه",'ظ' to "ظافر",'ع' to "عمر",'غ' to "غسان",'ف' to "فهد",
            'ق' to "قيس",'ك' to "كريم",'ل' to "ليث",'م' to "محمد",'ن' to "نبيل",
            'ه' to "هشام",'و' to "وليد",'ي' to "يوسف"),
        "girl" to mapOf('ا' to "أسماء",'ب' to "بشرى",'ت' to "تقى",'ث' to "ثريا",'ج' to "جنان",
            'ح' to "حنان",'خ' to "خديجة",'د' to "دانة",'ذ' to "ذكرى",'ر' to "رجاء",
            'ز' to "زينب",'س' to "سلمى",'ش' to "شيماء",'ص' to "صفاء",'ض' to "ضحى",
            'ط' to "طيبة",'ظ' to "ظبية",'ع' to "عائشة",'غ' to "غالية",'ف' to "فاطمة",
            'ق' to "قمر",'ك' to "كوثر",'ل' to "لبنى",'م' to "مريم",'ن' to "نادية",
            'ه' to "هدى",'و' to "وجدان",'ي' to "ياسمين"),
        "animal" to mapOf('ا' to "أسد",'ب' to "بقرة",'ت' to "تمساح",'ث' to "ثعلب",'ج' to "جمل",
            'ح' to "حصان",'خ' to "خروف",'د' to "دب",'ذ' to "ذباب",'ر' to "راكون",
            'ز' to "زرافة",'س' to "سمكة",'ش' to "شبل",'ص' to "صقر",'ض' to "ضفدع",
            'ط' to "طاووس",'ظ' to "ظبي",'ع' to "عصفور",'غ' to "غزال",'ف' to "فيل",
            'ق' to "قنفذ",'ك' to "كنغر",'ل' to "لاما",'م' to "ماعز",'ن' to "نمر",
            'ه' to "هدهد",'و' to "وعل",'ي' to "يمام"),
        "thing" to mapOf('ا' to "إبرة",'ب' to "بيت",'ت' to "تلفاز",'ث' to "ثلاجة",'ج' to "جرس",
            'ح' to "حقيبة",'خ' to "خاتم",'د' to "دراجة",'ذ' to "ذهب",'ر' to "راديو",
            'ز' to "زجاجة",'س' to "سرير",'ش' to "شمسية",'ص' to "صابون",'ض' to "ضوء",
            'ط' to "طاولة",'ظ' to "ظرف",'ع' to "عجلة",'غ' to "غطاء",'ف' to "فرشاة",
            'ق' to "قلم",'ك' to "كرسي",'ل' to "لوح",'م' to "مفتاح",'ن' to "نظارة",
            'ه' to "هاتف",'و' to "ورق",'ي' to "ياقوت"),
        "plant" to mapOf('ا' to "أرز",'ب' to "برتقال",'ت' to "تين",'ث' to "ثوم",'ج' to "جزرة",
            'ح' to "حلبة",'خ' to "خيار",'د' to "دفلة",'ذ' to "ذرة",'ر' to "ريحان",
            'ز' to "زيتون",'س' to "سبانخ",'ش' to "شبت",'ص' to "صبار",
            'ط' to "طماطم",'ع' to "عنب",'غ' to "غار",'ف' to "فراولة",'ق' to "قصب",
            'ك' to "كزبرة",'ل' to "ليمون",'م' to "موز",'ن' to "نعناع",'ه' to "هليون",
            'و' to "وردة",'ي' to "يقطين"),
        "country" to mapOf('ا' to "إثيوبيا",'ب' to "بلجيكا",'ت' to "تونس",'ج' to "جيبوتي",
            'د' to "دومينيكا",'ر' to "روسيا",'ز' to "زيمبابوي",'س' to "سوريا",
            'ع' to "عمان",'غ' to "غانا",'ف' to "فرنسا",'ق' to "قطر",
            'ك' to "كندا",'ل' to "ليبيا",'م' to "مالي",'ن' to "نيجيريا",'ه' to "هولندا"),
        "capital" to mapOf('ا' to "أبوظبي",'ب' to "بغداد",'ت' to "تونس",'ج' to "جاكرتا",
            'د' to "دمشق",'ر' to "ريغا",'ز' to "زغرب",'س' to "سكوبيه",
            'ص' to "صنعاء",'ط' to "طهران",'ع' to "عمان",'ف' to "فادوز",
            'ك' to "كابول",'ل' to "لندن",'م' to "مسقط",'ن' to "نيامي",
            'ه' to "هراري",'و' to "واشنطن",'ي' to "يريفان")
    )

    private fun normalizeArabic(c: Char): Char = when (c) {
        'أ', 'إ', 'آ' -> 'ا'
        'ؤ' -> 'و'
        'ئ' -> 'ي'
        'ى' -> 'ي'
        'ة' -> 'ه'
        else -> c
    }

    // ----- shortcuts: type trigger + space => expansion (multi-word triggers work too) -----
    private fun loadShortcuts(): Map<String, String> = Shortcuts.load(prefs)

    private fun tryExpand(): Boolean {
        if (!prefs.getBoolean("sc_auto", true)) return false
        val ic = currentInputConnection ?: return false
        val before = ic.getTextBeforeCursor(64, 0)?.toString() ?: return false
        if (before.isEmpty()) return false
        val list = loadShortcuts().entries.sortedByDescending { it.key.length }
        for (e in list) {
            val trig = e.key
            if (trig.isEmpty() || !before.endsWith(trig, ignoreCase = true)) continue
            val start = before.length - trig.length
            // the trigger must be a whole word, not the tail of a longer word
            if (start > 0 && before[start - 1].isLetterOrDigit()) continue
            ic.deleteSurroundingText(trig.length, 0)
            ic.commitText(e.value + " ", 1)
            return true
        }
        return false
    }

    override fun onText(t: String) {
        haptic(); clickSound()
        val ic = currentInputConnection ?: return

        // spelling game: one word is sent for EVERY selected category
        if (selectedCats.isNotEmpty() && t.length == 1 && t[0].isLetter()) {
            val letter = normalizeArabic(t[0])
            val words = mutableListOf<String>()
            val shown = mutableListOf<String>()
            for (catKey in catNames.keys) {
                if (catKey !in selectedCats) continue
                val word = catData[catKey]?.get(letter) ?: continue
                words.add(word)
                shown.add(catNames[catKey] + ": " + word)
            }
            catLabel.visibility = View.VISIBLE
            if (words.isNotEmpty()) {
                ic.commitText(words.joinToString("، ") + " ", 1)
                catLabel.text = "✅ " + shown.joinToString("  |  ")
            } else {
                catLabel.text = "😅 لا توجد كلمة بحرف «" + t + "» في الأقسام المختارة — جرّب حرفاً آخر"
            }
            updateCandidates()
            return
        }

        // separated spelling (ا ح م د), dotted (1.3.4) and reversed (123 -> 321) typing modes
        val isChar = t.length == 1 && t[0].isLetterOrDigit()
        val sepStr = if (!isChar) "" else when {
            separate() && dots() && t[0].isLetter() -> ". "
            separate() && t[0].isLetter() -> " "
            dots() -> "."
            else -> ""
        }
        val piece = t + sepStr
        if (isChar && reverse()) {
            val before = ic.getTextBeforeCursor(64, 0)?.toString() ?: ""
            val unit = if (sepStr.isEmpty()) "[\\p{L}\\p{N}]" else "[\\p{L}\\p{N}]" + Regex.escape(sepStr)
            val run = Regex("(?:$unit)*$").find(before)?.value ?: ""
            if (run.isNotEmpty()) { ic.deleteSurroundingText(run.length, 0); ic.commitText(piece + run, 1) }
            else ic.commitText(piece, 1)
        } else ic.commitText(piece, 1)
        if (!capsLock) shift = false
        kv.shiftActive = shift; kv.capsActive = capsLock
        kv.invalidate()
        updateCandidates()
    }

    private fun dots(): Boolean = prefs.getBoolean("dots", false)
    private fun reverse(): Boolean = prefs.getBoolean("reverse", false)
    private fun toggleDots() { haptic(); prefs.edit().putBoolean("dots", !dots()).apply(); updateCandidates() }
    private fun toggleReverse() { haptic(); prefs.edit().putBoolean("reverse", !reverse()).apply(); updateCandidates() }

    // ----- backspace: handles selection, emoji and separated mode -----
    private fun deleteBack() {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) { ic.commitText("", 1); return }
        if (separate() || dots()) {
            val b = ic.getTextBeforeCursor(3, 0)?.toString() ?: ""
            if (separate() && dots() && b.length == 3 && b.endsWith(". ") && b[0].isLetterOrDigit()) {
                ic.deleteSurroundingText(3, 0); return
            }
            if (b.length >= 2 && b[b.length - 2].isLetterOrDigit() &&
                ((separate() && b.last() == ' ') || (dots() && b.last() == '.'))) {
                ic.deleteSurroundingText(2, 0)   // char + its separator together
                return
            }
        }
        ic.deleteSurroundingTextInCodePoints(1, 0)
    }

    private fun trimTrailingSpaces(ic: InputConnection) {
        val b = ic.getTextBeforeCursor(64, 0)?.toString() ?: return
        var n = 0
        while (n < b.length && b[b.length - 1 - n] == ' ') n++
        if (n > 0) ic.deleteSurroundingText(n, 0)
    }

    // ----- ➤ send button (like iPhone): runs the field's action, or SEND when it has none -----
    private fun doSend() {
        val ic = currentInputConnection ?: return
        if (separate() || dots()) {
            trimTrailingSpaces(ic)
            if (dots() && ic.getTextBeforeCursor(1, 0)?.toString() == ".") ic.deleteSurroundingText(1, 0)
        }
        learnWord()
        val ei = currentInputEditorInfo
        val flags = ei?.imeOptions ?: 0
        val action = flags and EditorInfo.IME_MASK_ACTION
        val noAction = flags and EditorInfo.IME_FLAG_NO_ENTER_ACTION != 0
        val customId = ei?.actionId ?: 0
        if (customId != 0 && ei?.actionLabel != null) {
            ic.performEditorAction(customId)
        } else if (!noAction && action != EditorInfo.IME_ACTION_NONE &&
            action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            if (!ic.performEditorAction(EditorInfo.IME_ACTION_SEND)) {
                sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
            }
        }
    }

    private fun toggleSeparate() {
        haptic()
        prefs.edit().putBoolean("separate", !separate()).apply()
        updateCandidates()
    }

    override fun onSpecial(token: String) {
        val ic = currentInputConnection ?: return
        when (token) {
            "@DEL" -> { haptic(); deleteBack(); updateCandidates() }
            "@DEL_WORD" -> { haptic(); deleteWord(); updateCandidates() }
            "@DEL_ALL" -> {
                haptic()
                val before = ic.getTextBeforeCursor(4096, 0)?.length ?: 0
                val after = ic.getTextAfterCursor(4096, 0)?.length ?: 0
                ic.deleteSurroundingText(before, after)
                updateCandidates()
            }
            "@SPACE" -> {
                haptic(); clickSound()
                if (!separate() && tryExpand()) { updateCandidates(); return }
                learnWord()
                // separated mode: an extra space = gap between two words
                ic.commitText(" ", 1); updateCandidates()
            }
            "@ENTER" -> {
                haptic(); clickSound()
                if (!separate() && tryExpand()) { updateCandidates(); return }
                learnWord()
                val action = enterAction()
                if (action != EditorInfo.IME_ACTION_NONE) ic.performEditorAction(action)
                else ic.commitText("\n", 1)
                updateCandidates()
            }
            "@SEND" -> {
                haptic(); clickSound()
                doSend()
                updateCandidates()
            }
            "@SHIFT" -> {
                when {
                    capsLock -> { capsLock = false; shift = false }
                    shift -> { shift = false; capsLock = true }
                    else -> shift = true
                }
                refresh()
            }
            "@LANG", "@LANG_BACK" -> {
                val fwd = token == "@LANG"
                page = when (page) {
                    Page.AR -> if (fwd) Page.FR else Page.EN
                    Page.FR -> if (fwd) Page.EN else Page.AR
                    Page.EN -> if (fwd) Page.AR else Page.FR
                    else -> lastAlpha
                }
                if (page == Page.AR || page == Page.FR || page == Page.EN) lastAlpha = page
                if (page == Page.FR || page == Page.EN) lastLatin = page
                shift = false; capsLock = false
                refresh()
            }
            "@ABCL" -> { page = lastLatin; lastAlpha = lastLatin; refresh() }
            "@MIC" -> toggleStt()
            "@MIC_LONG" -> toggleSttSource()
            "@CAT" -> {
                if (catBar.visibility == View.VISIBLE) {
                    catBar.visibility = View.GONE
                    selectedCats.clear()
                    catLabel.visibility = View.GONE
                } else {
                    catBar.visibility = View.VISIBLE
                    updateCatUI()
                }
                updateCandidates()
            }
            "@NUM" -> { page = Page.NUM; refresh() }
            "@NUMPAD" -> { page = Page.NUMPAD; refresh() }
            "@PUNCT" -> { ic.commitText("٪", 1) }
            "@SYM" -> { page = Page.SYM; refresh() }
            "@ABC" -> {
                page = when (page) {
                    Page.NUMPAD -> Page.NUM
                    Page.NUM -> { lastAlpha = Page.AR; Page.AR }
                    else -> lastAlpha
                }
                refresh()
            }
            "@EMOJI" -> { page = Page.EMOJI; refresh() }
            "@SET" -> {
                // open the settings panel (like iPhone's keyboard settings)
                val intent = android.content.Intent(this, SettingsActivity::class.java)
                    .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                runCatching { startActivity(intent) }
            }
            "@SET_LONG" -> {
                // quick theme cycle without leaving the keyboard
                val t2 = (theme() + 1) % Themes.COUNT
                prefs.edit().putInt("theme", t2).apply()
                refresh()
            }
        }
    }

    // ---------------- spelling-game selection ----------------

    private fun toggleCategory(key: String) {
        haptic()
        if (key == ALL_KEY) {
            if (selectedCats.size == catNames.size) selectedCats.clear()
            else selectedCats.addAll(catNames.keys)
        } else {
            if (key in selectedCats) selectedCats.remove(key)
            else selectedCats.add(key)
        }
        updateCatUI()
    }

    private fun updateCatUI() {
        val c = colors()
        for ((key, chip) in catChips) {
            val on = if (key == ALL_KEY) selectedCats.size == catNames.size else key in selectedCats
            chip.setTextColor(if (on) c.third else c.second)
            chip.paint.isFakeBoldText = on
            chip.alpha = if (on) 1.0f else 0.75f
        }
        if (selectedCats.isEmpty()) {
            catLabel.visibility = View.GONE
        } else {
            catLabel.visibility = View.VISIBLE
            val names = catNames.filterKeys { it in selectedCats }.values
            catLabel.text = "🎯 اكتب الحرف:  " + names.joinToString(" + ")
        }
    }

    private fun deleteWord() {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) { ic.commitText("", 1); return }
        val t = ic.getTextBeforeCursor(64, 0) ?: return
        var n = 0
        var i = t.length
        while (i > 0 && t[i - 1] == ' ') { i--; n++ }
        if (separate()) {
            // letters separated by single spaces form one "word"
            while (i > 0 && t[i - 1].isLetterOrDigit()) {
                i--; n++
                if (i > 0 && t[i - 1] == ' ' && (i < 2 || t[i - 2] != ' ')) { i--; n++ } else break
            }
        } else {
            while (i > 0 && (t[i - 1].isLetterOrDigit() || t[i - 1] == '\'')) { i--; n++ }
        }
        ic.deleteSurroundingText(n.coerceAtLeast(1), 0)
    }

    // ---------------- suggestions & learning ----------------

    private fun currentWord(): String {
        val ic = currentInputConnection ?: return ""
        val t = ic.getTextBeforeCursor(32, 0) ?: return ""
        val m = Regex("[\\p{L}\\p{N}']+$").find(t) ?: return ""
        return m.value
    }

    private fun suggest(prefix: String): List<String> {
        if (prefix.length < 2) return emptyList()
        val base = when (lastAlpha) { Page.FR -> frWords; Page.EN -> enWords; else -> arWords }
        val learned = prefs.getStringSet("learned", emptySet())!!.toList()
        val scored = mutableListOf<Pair<Int, String>>()
        for (w in (base + learned).distinct()) {
            if (w == prefix) continue
            if (!w.startsWith(prefix, ignoreCase = true)) continue
            val score = prefs.getInt("f_$w", 1) * 10 + w.length.coerceAtMost(9)
            scored.add(score to w)
        }
        return scored.sortedByDescending { it.first }.take(3).map { it.second }
    }

    private fun learnWord() {
        // in separated mode the "word" is one letter — skip learning
        if (separate()) return
        val w = currentWord().lowercase(Locale.ROOT)
        if (w.length < 2) return
        val set = prefs.getStringSet("learned", emptySet())!!.toMutableSet()
        if (set.size < 400) set.add(w)
        prefs.edit().putStringSet("learned", set)
            .putInt("f_$w", prefs.getInt("f_$w", 0) + 1).apply()
    }

    // ---------------- top bar: voice pill + (suggestions + tool pills) in one scrolling row ----------------

    private lateinit var sugBox: LinearLayout
    private lateinit var toolsRow: LinearLayout
    private val tools = HashMap<String, TextView>()
    private var lastSig = ""
    private val candRunnable = Runnable { doUpdateCandidates() }

    private fun makePill(onClick: () -> Unit, onLong: (() -> Unit)? = null): TextView = TextView(this).apply {
        textSize = 13f
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(7), dp(12), dp(7))
        setOnClickListener { onClick() }
        if (onLong != null) setOnLongClickListener { onLong(); true }
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(60).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(110).start()
            }
            false
        }
    }

    private fun addTool(key: String, onClick: () -> Unit, onLong: (() -> Unit)? = null) {
        val tv = makePill(onClick, onLong)
        tools[key] = tv
        toolsRow.addView(tv, LinearLayout.LayoutParams(WRAP, WRAP).apply { setMargins(dp(3), 0, dp(3), 0) })
    }

    private fun buildBars() {
        candidateBar.removeAllViews()
        candidateBar.gravity = Gravity.CENTER_VERTICAL
        candidateBar.minimumHeight = dp(46)
        candidateBar.setPadding(dp(4), dp(3), dp(4), dp(3))
        tools.clear()

        val voice = makePill({ toggleStt() }, { toggleSttSource() })
        tools["voice"] = voice
        candidateBar.addView(voice, LinearLayout.LayoutParams(WRAP, WRAP).apply { setMargins(dp(3), 0, dp(4), 0) })

        val scroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        sugBox = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        toolsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        inner.addView(sugBox, LinearLayout.LayoutParams(WRAP, WRAP))
        inner.addView(toolsRow, LinearLayout.LayoutParams(WRAP, WRAP))
        scroll.addView(inner)
        candidateBar.addView(scroll, LinearLayout.LayoutParams(0, WRAP, 1f))

        addTool("sep", { toggleSeparate() })
        addTool("dots", { toggleDots() })
        addTool("rev", { toggleReverse() })
        addTool("sc", { toggleScPanel() })
        addTool("game", { onSpecial("@CAT") })
        addTool("clip", { toggleClipPanel() })
        addTool("set", { onSpecial("@SET") }, { onSpecial("@SET_LONG") })
    }

    private fun stylePill(key: String, label: String, active: Boolean, p: Palette) {
        val tv = tools[key] ?: return
        val sig = label + active + theme()
        if (tv.tag == sig) return
        tv.tag = sig
        tv.text = label
        tv.setTextColor(if (active) p.enterText else p.text)
        tv.background = roundBg(if (active) p.enterBg else p.key, 17)
    }

    private fun updateToolbarState(p: Palette) {
        val on = micOn()
        stylePill("voice", if (on) "⏹ إيقاف" else if (sttRoom()) "🔊 الغرفة" else "🎤 صوت", on, p)
        stylePill("sep", "✂ تفكيك", separate(), p)
        stylePill("dots", "• نقط", dots(), p)
        stylePill("rev", "⇄ عكس", reverse(), p)
        stylePill("sc", "⚡ اختصارات", scVisible(), p)
        stylePill("game", "🎯 لعبة", ::catBar.isInitialized && catBar.visibility == View.VISIBLE, p)
        val clipOn = ::clipPanel.isInitialized && clipPanel.visibility == View.VISIBLE
        stylePill("clip", "📋 حافظة", clipOn, p)
        tools["clip"]?.visibility = if (clipEnabled()) View.VISIBLE else View.GONE
        stylePill("set", "⚙", false, p)
        if (::kv.isInitialized) kv.micActive = on
    }

    private fun sugChip(text: String, bold: Boolean, p: Palette, onClick: () -> Unit): TextView =
        TextView(this).apply {
            this.text = text
            textSize = 16f
            setTextColor(if (bold) p.special else p.text)
            gravity = Gravity.CENTER
            background = roundBg(p.key, 17)
            setPadding(dp(14), dp(6), dp(14), dp(6))
            setOnClickListener { onClick() }
        }

    // typing calls this a lot: coalesce into one update per ~30ms
    private fun updateCandidates() {
        if (!::candidateBar.isInitialized) return
        candidateBar.removeCallbacks(candRunnable)
        candidateBar.postDelayed(candRunnable, 30)
    }

    private fun doUpdateCandidates() {
        if (!::sugBox.isInitialized) return
        val p = Themes.get(theme())
        candidateBar.setBackgroundColor(p.bg)
        updateToolbarState(p)

        val cur = currentWord()
        val clip: ClipItem? = if (clipEnabled() && cur.isEmpty()) {
            val last = clipStore.latest()
            if (last != null && last.time != dismissedClipTime &&
                System.currentTimeMillis() - last.time < 120_000L) last else null
        } else null
        val sugs = suggest(cur)
        val sig = "${theme()}|$sttMsg|$sttPartial|${clip?.time}|${sugs.joinToString(",")}|${cur.isNotEmpty()}"
        if (sig == lastSig) return
        lastSig = sig

        sugBox.removeAllViews()
        fun add(v: View) = sugBox.addView(v,
            LinearLayout.LayoutParams(WRAP, WRAP).apply { setMargins(dp(3), 0, dp(3), 0) })
        if (sttMsg.isNotEmpty()) add(sugChip(sttMsg, false, p) { sttMsg = ""; updateCandidates() })
        else if (sttPartial.isNotEmpty()) add(sugChip("🎙 $sttPartial", false, p) { })
        if (clip != null) {
            val flat = clip.text.replace("\n", " ").trim()
            val shown = if (flat.length > 16) flat.take(16) + "…" else flat
            add(sugChip("📋 $shown", true, p) {
                currentInputConnection?.commitText(clip.text, 1)
                dismissedClipTime = clip.time
                updateCandidates()
            })
        }
        for (s in sugs) add(sugChip(s, true, p) { applySuggestion(s) })
        if (cur.isNotEmpty()) add(sugChip("✓", false, p) {
            learnWord(); currentInputConnection?.commitText(" ", 1); updateCandidates()
        })
    }

    private fun applySuggestion(sug: String) {
        val ic = currentInputConnection ?: return
        val w = currentWord()
        ic.deleteSurroundingText(w.length, 0)
        ic.commitText(sug + " ", 1)
        prefs.edit().putInt("f_$sug", prefs.getInt("f_$sug", 0) + 3).apply()
        updateCandidates()
    }

    private fun colors(): Triple<Int, Int, Int> {
        val p = Themes.get(theme())
        return Triple(p.bg, p.text, p.special)
    }

    // ---------------- voice typing ----------------
    // 🎤 normal dictation (system recognizer, like any other keyboard)
    // 🔊 room mode: records the app's playback (MediaProjection) and transcribes it offline (Vosk)

    private var sttPartial = ""
    private var sttMsg = ""
    private var sr: SpeechRecognizer? = null
    private var srActive = false
    private val srHandler = Handler(Looper.getMainLooper())
    private val srRestart = Runnable { if (srActive) listenOnce() }

    private fun sttRoom(): Boolean = prefs.getBoolean("stt_room", false)
    private fun micOn(): Boolean = srActive || SttBridge.active()

    private fun dictLang(): String = when (lastAlpha) { Page.FR -> "fr"; Page.EN -> "en"; else -> "ar" }
    private fun dictTag(): String = when (lastAlpha) { Page.FR -> "fr-FR"; Page.EN -> "en-US"; else -> "ar-DZ" }

    private fun syncMic() { if (::kv.isInitialized) kv.micActive = micOn() }

    private fun toggleSttSource() {
        haptic()
        if (micOn()) stopStt()
        prefs.edit().putBoolean("stt_room", !sttRoom()).apply()
        sttMsg = if (sttRoom()) "🔊 وضع الغرفة: يلتقط صوت اللعبة/الغرفة" else "🎤 وضع المايك العادي"
        updateCandidates()
    }

    private fun stopStt() {
        stopSr()
        if (SttBridge.active()) runCatching {
            startService(Intent(this, RoomListenService::class.java)
                .setAction(RoomListenService.ACTION_STOP))
        }
        syncMic(); updateCandidates()
    }

    private fun toggleStt() {
        haptic()
        sttMsg = ""
        if (micOn()) { stopStt(); return }
        if (sttRoom()) {
            val i = Intent(this, SttSetupActivity::class.java)
                .putExtra("lang", dictLang()).putExtra("room", true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            runCatching { startActivity(i) }
        } else startDictation()
    }

    private fun startDictation() {
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            val i = Intent(this, SttSetupActivity::class.java)
                .putExtra("mode", "sr").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            runCatching { startActivity(i) }
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            sttMsg = "⚠ لا يتوفر تعرّف صوتي على الجهاز — جرّب 🔊 (نقر مطوّل على الزر)"
            updateCandidates(); return
        }
        stopSr()
        srActive = true
        sr = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(srListener) }
        sttMsg = "👂 تحدّث الآن"
        syncMic(); updateCandidates()
        listenOnce()
    }

    private fun listenOnce() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, dictTag())
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        runCatching { sr?.startListening(i) }
    }

    private fun stopSr() {
        val was = srActive
        srActive = false
        srHandler.removeCallbacks(srRestart)
        runCatching { sr?.cancel() }
        runCatching { sr?.destroy() }
        sr = null
        sttPartial = ""
        if (was) { sttMsg = ""; syncMic(); updateCandidates() }
    }

    private val srListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: android.os.Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: android.os.Bundle?) {}

        override fun onPartialResults(b: android.os.Bundle?) {
            val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
            sttMsg = ""; sttPartial = t; updateCandidates()
        }

        override fun onResults(b: android.os.Bundle?) {
            val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim() ?: ""
            sttPartial = ""
            if (t.isNotEmpty()) currentInputConnection?.commitText("$t ", 1)
            updateCandidates()
            if (srActive) srHandler.postDelayed(srRestart, 150)
        }

        override fun onError(error: Int) {
            sttPartial = ""
            when (error) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                    if (srActive) srHandler.postDelayed(srRestart, 150)
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                    runCatching { sr?.cancel() }
                    if (srActive) srHandler.postDelayed(srRestart, 500)
                }
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    stopSr(); sttMsg = "⚠ صلاحية المايك مرفوضة"; updateCandidates()
                }
                else -> {
                    stopSr(); sttMsg = "⚠ تعذّر التعرف على الصوت (رمز $error)"; updateCandidates()
                }
            }
        }
    }

    // results from the room-capture engine (Vosk)
    private val sttSink = object : SttBridge.Sink {
        override fun onPartial(t: String) { sttPartial = t; updateCandidates() }
        override fun onFinal(t: String) {
            sttPartial = ""
            val ic = currentInputConnection
            if (ic != null) ic.commitText("$t ", 1) else sttMsg = "افتح خانة الكتابة ليُكتب النص"
            updateCandidates()
        }
        override fun onState(s: String) {
            when (s) {
                "perm_ok" -> { startDictation(); return }
                "downloading" -> sttMsg = "⬇ تنزيل نموذج اللغة…"
                "loading" -> sttMsg = "⏳ تحميل…"
                "listening" -> sttMsg = "👂 يستمع للغرفة"
                else -> if (sttMsg.startsWith("⬇") || sttMsg.startsWith("⏳") || sttMsg.startsWith("👂")) sttMsg = ""
            }
            if (s == "stopped") sttPartial = ""
            syncMic(); updateCandidates()
        }
        override fun onProgress(p: Int) { sttMsg = "⬇ $p%"; updateCandidates() }
        override fun onError(m: String) { sttMsg = "⚠ $m"; updateCandidates() }
    }

    // ---------------- clipboard ----------------

    private lateinit var clipPanel: LinearLayout
    private lateinit var clipManager: ClipboardManager
    private lateinit var clipStore: ClipboardStore
    private var dismissedClipTime = 0L
    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener { captureClip() }

    private fun clipEnabled(): Boolean = prefs.getBoolean("clip_enabled", true)

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun roundBg(fill: Int, radiusDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = dp(radiusDp).toFloat()
        return g
    }

    private fun pillView(text: String, bg: Int, fg: Int, sizeSp: Float = 15f,
                         onClick: () -> Unit): TextView = TextView(this).apply {
        this.text = text
        textSize = sizeSp
        setTextColor(fg)
        gravity = Gravity.CENTER
        background = roundBg(bg, 12)
        setPadding(dp(10), dp(7), dp(10), dp(7))
        setOnClickListener { onClick() }
    }

    private fun captureClip() {
        if (!clipEnabled()) return
        val clip = clipManager.primaryClip ?: return
        if (clip.itemCount == 0) return
        // skip content apps mark as sensitive (passwords, OTP, ...)
        val sensitive = clip.description?.extras?.getBoolean("android.content.extra.IS_SENSITIVE", false)
        if (sensitive == true) return
        val text = clip.getItemAt(0).coerceToText(this)?.toString() ?: return
        clipStore.add(text)
        if (::candidateBar.isInitialized) updateCandidates()
        if (::clipPanel.isInitialized && clipPanel.visibility == View.VISIBLE) rebuildClipPanel()
    }

    private fun showClipPanel() {
        if (scVisible()) scPanel.visibility = View.GONE
        val h = panelHeight()
        clipPanel.layoutParams = LinearLayout.LayoutParams(MATCH, h)
        rebuildClipPanel()
        kv.visibility = View.GONE
        clipPanel.visibility = View.VISIBLE
    }

    private fun hideClipPanel() {
        clipPanel.visibility = View.GONE
        kv.visibility = View.VISIBLE
    }

    private fun toggleClipPanel() {
        haptic()
        if (clipPanel.visibility == View.VISIBLE) hideClipPanel() else showClipPanel()
    }

    private fun rebuildClipPanel() {
        val p = Themes.get(theme())
        clipPanel.removeAllViews()
        clipPanel.setBackgroundColor(p.bg)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(6), dp(10), dp(4))
        }
        header.addView(TextView(this).apply {
            text = "📋 الحافظة"
            textSize = 16f
            setTextColor(p.special)
            paint.isFakeBoldText = true
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        header.addView(pillView("🗑 مسح", p.key, p.text, 13f) {
            clipStore.clearUnpinned(); rebuildClipPanel()
        }, LinearLayout.LayoutParams(WRAP, WRAP).apply { setMargins(dp(4), 0, dp(4), 0) })
        header.addView(pillView("⌨ رجوع", p.enterBg, p.enterText, 13f) { hideClipPanel() })
        clipPanel.addView(header, LinearLayout.LayoutParams(MATCH, WRAP))

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val items = clipStore.displayList()
        if (items.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "لا يوجد شيء بعد 📭\nانسخ أي نص وسيظهر هنا تلقائياً"
                textSize = 14f
                gravity = Gravity.CENTER
                setTextColor(p.hint)
                setPadding(dp(16), dp(28), dp(16), dp(28))
            }, LinearLayout.LayoutParams(MATCH, WRAP))
        } else {
            for (item in items) {
                list.addView(clipRow(item, p), LinearLayout.LayoutParams(MATCH, WRAP).apply {
                    setMargins(dp(8), dp(3), dp(8), dp(3))
                })
            }
        }
        val scroll = ScrollView(this)
        scroll.addView(list)
        clipPanel.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
    }

    private fun iconBtn(text: String, a: Float, p: Palette, onClick: () -> Unit): TextView =
        TextView(this).apply {
            this.text = text
            textSize = 16f
            gravity = Gravity.CENTER
            alpha = a
            setTextColor(p.text)
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setOnClickListener { onClick() }
        }

    private fun clipRow(item: ClipItem, p: Palette): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val tv = TextView(this).apply {
            text = item.text.trim()
            textSize = 15f
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(p.text)
            background = roundBg(p.key, 12)
            setPadding(dp(12), dp(9), dp(12), dp(9))
            setOnClickListener {
                haptic(); clickSound()
                currentInputConnection?.commitText(item.text, 1)
                hideClipPanel()
                updateCandidates()
            }
        }
        row.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(iconBtn("📌", if (item.pinned) 1f else 0.3f, p) {
            haptic(); clipStore.togglePin(item.text); rebuildClipPanel()
        })
        row.addView(iconBtn("✕", 0.7f, p) {
            haptic(); clipStore.remove(item.text); rebuildClipPanel()
        })
        return row
    }

    // ---------------- shortcuts panel: pick ONE or MORE shortcuts, then insert ----------------

    private lateinit var scPanel: LinearLayout
    private val scSelected = mutableListOf<String>()
    private val scRows = HashMap<String, Pair<TextView, TextView>>()
    private var scInsertBtn: TextView? = null
    private var panelH = 0

    private fun scVisible(): Boolean = ::scPanel.isInitialized && scPanel.visibility == View.VISIBLE

    private fun panelHeight(): Int {
        if (kv.visibility == View.VISIBLE && kv.height > 0) panelH = kv.height
        return maxOf(panelH, dp(216))
    }

    private fun scInsertText(): String =
        if (scSelected.isEmpty()) "إدراج" else "إدراج (" + scSelected.size + ")"

    private fun showScPanel() {
        if (::clipPanel.isInitialized && clipPanel.visibility == View.VISIBLE) clipPanel.visibility = View.GONE
        val h = panelHeight()
        scPanel.layoutParams = LinearLayout.LayoutParams(MATCH, h)
        rebuildScPanel()
        kv.visibility = View.GONE
        scPanel.visibility = View.VISIBLE
    }

    private fun hideScPanel() {
        scPanel.visibility = View.GONE
        kv.visibility = View.VISIBLE
    }

    private fun toggleScPanel() {
        haptic()
        if (scVisible()) hideScPanel() else showScPanel()
        updateCandidates()
    }

    private fun styleScRow(trig: String, p: Palette) {
        val v = scRows[trig] ?: return
        val on = trig in scSelected
        v.first.text = if (on) "☑" else "☐"
        v.first.setTextColor(if (on) p.special else p.hint)
        v.second.background = roundBg(if (on) p.keyAlt else p.key, 12)
    }

    private fun toggleSc(trig: String) {
        if (!scSelected.remove(trig)) scSelected.add(trig)
        styleScRow(trig, Themes.get(theme()))
        scInsertBtn?.text = scInsertText()
    }

    private fun insertSelectedShortcuts() {
        if (scSelected.isEmpty()) return
        haptic(); clickSound()
        val map = loadShortcuts()
        val text = scSelected.mapNotNull { map[it] }.joinToString(" ")
        currentInputConnection?.commitText(text + " ", 1)
        scSelected.clear()
        hideScPanel()
        updateCandidates()
    }

    private fun rebuildScPanel() {
        val p = Themes.get(theme())
        scPanel.removeAllViews()
        scPanel.setBackgroundColor(p.bg)
        scRows.clear()

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(6), dp(10), dp(4))
        }
        header.addView(TextView(this).apply {
            text = "⚡ الاختصارات"
            textSize = 16f
            setTextColor(p.special)
            paint.isFakeBoldText = true
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        val ins = pillView(scInsertText(), p.enterBg, p.enterText, 13f) { insertSelectedShortcuts() }
        scInsertBtn = ins
        header.addView(ins, LinearLayout.LayoutParams(WRAP, WRAP).apply { setMargins(dp(4), 0, dp(4), 0) })
        header.addView(pillView("⌨ رجوع", p.key, p.text, 13f) { hideScPanel(); updateCandidates() })
        scPanel.addView(header, LinearLayout.LayoutParams(MATCH, WRAP))

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val auto = prefs.getBoolean("sc_auto", true)
        list.addView(TextView(this).apply {
            text = (if (auto) "☑" else "☐") + " توسيع تلقائي: اكتب الاختصار ثم مسافة"
            textSize = 13f
            setTextColor(p.hint)
            setPadding(dp(16), dp(4), dp(16), dp(6))
            setOnClickListener {
                prefs.edit().putBoolean("sc_auto", !prefs.getBoolean("sc_auto", true)).apply()
                rebuildScPanel()
            }
        }, LinearLayout.LayoutParams(MATCH, WRAP))

        val map = loadShortcuts().toSortedMap()
        if (map.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "لا توجد اختصارات 📭\nأضفها من ⚙ الإعدادات"
                textSize = 14f
                gravity = Gravity.CENTER
                setTextColor(p.hint)
                setPadding(dp(16), dp(28), dp(16), dp(28))
            }, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        for ((trig, exp) in map) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val box = TextView(this).apply {
                textSize = 20f
                gravity = Gravity.CENTER
                setPadding(dp(6), 0, dp(10), 0)
            }
            val body = TextView(this).apply {
                text = trig + "  ←  " + exp
                textSize = 15f
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                setTextColor(p.text)
                setPadding(dp(12), dp(9), dp(12), dp(9))
            }
            row.addView(box, LinearLayout.LayoutParams(WRAP, WRAP))
            row.addView(body, LinearLayout.LayoutParams(0, WRAP, 1f))
            row.setOnClickListener { haptic(); toggleSc(trig) }
            scRows[trig] = Pair(box, body)
            styleScRow(trig, p)
            list.addView(row, LinearLayout.LayoutParams(MATCH, WRAP).apply {
                setMargins(dp(8), dp(3), dp(8), dp(3))
            })
        }
        val scroll = ScrollView(this)
        scroll.addView(list)
        scPanel.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
    }

    companion object {
        private const val ALL_KEY = "all"
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    }
}
